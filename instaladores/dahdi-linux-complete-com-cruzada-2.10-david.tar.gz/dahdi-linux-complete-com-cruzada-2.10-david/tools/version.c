/*
 * version.c
 * Automatically generated
 */

const char dahdi_tools_version[] = "DAHDI Tools Version - 2.10.2";

