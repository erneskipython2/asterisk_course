/*
 * version.h 
 * Automatically generated
 */
#define DAHDI_VERSION "2.10.2"

